plugins {
    id("com.android.application")
}

android {
    namespace = "pt.tv25.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "pt.tv25.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "10.0-test"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = false
        }
    }
}
