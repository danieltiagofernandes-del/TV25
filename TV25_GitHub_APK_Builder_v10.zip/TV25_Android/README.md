# TV25 Android v7

Correções sobre a v5:
- Mantém a correção do crash de arranque.
- Links/páginas externas deixam de substituir a interface TV25 dentro da WebView.
- O botão “Abrir fonte” abre a página externa no navegador.
- No Android, o modo Automático prefere HLS nativo do WebView, reduzindo falhas MSE/CORS do HLS.js.
- O modo HLS continua disponível manualmente como alternativa.
- Mantém recuperação do renderer WebView, file picker, fullscreen, JavaScript, DOM storage e logo TV25.

Nota: uma fonte de TV pode continuar indisponível se o servidor remoto estiver offline,
bloquear o cliente, exigir autenticação, ou fornecer um codec/formato não suportado.


## TV25 v8
- Novo layout cinematográfico TV25 inspirado em interfaces de streaming modernas.
- Página Início com continuar a ver, favoritos e TV ao vivo.
- Secção Futebol com calendário diário online e associação jogo -> canal da lista.
- Botão Legendas AI no player. Requer endpoint próprio de transcrição: POST JSON {streamUrl, language, title}, resposta {vtt} ou {url}.
- Não inclui chaves secretas nem streams desportivos de terceiros.

## TV25 v9 verification
This build uses `clean assembleDebug --no-build-cache` and verifies the final APK itself contains `TV25_BUILD_V9_NETFLY_LAYOUT`, `TV25 ORIGINAL`, `Jogos de hoje`, and `Legendas AI`. The workflow fails if the old CineGrátis title is detected.
